const React = require("react");

function Square() {
  let side = 10;
  let a = side * side;
  return <h1>area of square : {a}</h1>;
}
export default Square;
