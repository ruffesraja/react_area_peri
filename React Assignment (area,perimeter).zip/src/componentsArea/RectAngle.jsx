const React = require("react");

function RectAngle() {
  let a = 10;
  let b = 20;
  let area = a * b;
  return <h1>area of rectangle : {area}</h1>;
}
export default RectAngle;
