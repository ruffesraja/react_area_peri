const React = require("react");

function RectAngle() {
  let a = 10;
  let b = 20;
  let peri = 2 * (a + b);
  return <h1>perimeter of rectangle : {peri}</h1>;
}
export default RectAngle;
