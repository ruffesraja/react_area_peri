const React = require("react");

function Square() {
  let side = 10;
  let peri = 4 * side;
  return <h1>perimeter of square : {peri}</h1>;
}
export default Square;
